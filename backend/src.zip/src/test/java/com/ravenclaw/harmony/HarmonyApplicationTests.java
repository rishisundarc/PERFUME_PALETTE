package com.ravenclaw.harmony;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HarmonyApplicationTests {

	@Test
	void contextLoads() {
	}

}

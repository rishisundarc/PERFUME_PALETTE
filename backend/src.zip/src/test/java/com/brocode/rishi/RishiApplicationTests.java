package com.brocode.rishi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RishiApplicationTests {

	@Test
	void contextLoads() {
	}

}

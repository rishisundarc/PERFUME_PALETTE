package com.brocode.rishi.controller;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.brocode.rishi.dto.UserDTO;
import com.brocode.rishi.dto.UserResponseDto;
import com.brocode.rishi.model.User;
import com.brocode.rishi.service.UserService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
@RestController
@RequestMapping("/api/user")
public class UserController {
	@Autowired
	UserService userService;
	@PostMapping("/post")
    public ResponseEntity<UserResponseDto> createEvent(@RequestBody UserDTO eventRequestDTO) {
        User event = new User();
        event.setFirstname(eventRequestDTO.getFirstname());
        event.setLastname(eventRequestDTO.getLastname());
        event.setUsername(eventRequestDTO.getUsername());
        event.setPassword(eventRequestDTO.getPassword());
        // Set other relevant fields
        // Call the service layer to create the event
        User createdEvent = userService.createUser(event);
        // Map the created event entity to the response DTO within the controller method
        UserResponseDto responseDTO = new UserResponseDto();
        responseDTO.setUserID(createdEvent.getUserID());
        responseDTO.setUsername(createdEvent.getUsername());
        responseDTO.setFirstname(createdEvent.getFirstname());
        responseDTO.setLastname(createdEvent.getLastname());
        // Set other relevant fields
        return ResponseEntity.ok(responseDTO);
    }
	@GetMapping("/get")
    public ResponseEntity<List<UserResponseDto>> getAllEvents() {
        // Call the service layer to retrieve all events
        List<User> events = userService.getAllUser();

        // Map the list of event entities to a list of response DTOs within the controller method
        List<UserResponseDto> responseDTOs = events.stream()
                .map(event -> {
                    UserResponseDto responseDTO = new UserResponseDto();
                    responseDTO.setUserID(event.getUserID());
                    responseDTO.setFirstname(event.getFirstname());
                    responseDTO.setLastname(event.getLastname());
                    responseDTO.setUsername(event.getUsername());
                    responseDTO.setPassword(event.getPassword());
                    // Set other relevant fields
                    return responseDTO;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(responseDTOs);
    }
	@DeleteMapping("/del/{userId}")
    public ResponseEntity<Void> deleteEvent(@PathVariable Integer userId) {
        // Call the service layer to delete the event by ID
        userService.deleteUser(userId);
        return ResponseEntity.noContent().build();
    }
}
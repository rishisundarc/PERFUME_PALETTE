package com.brocode.rishi.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.brocode.rishi.dto.TransactionRequestDTO;
import com.brocode.rishi.dto.TransactionResponseDTo;
import com.brocode.rishi.model.Transaction;
import com.brocode.rishi.model.User;
import com.brocode.rishi.dto.FlavourRequestDTO;
import com.brocode.rishi.service.TransactionService;
import com.brocode.rishi.service.UserService;

import java.util.List;
import java.util.stream.Collectors;
@RestController
@RequestMapping("/api/transaction")
public class TransactionController {
    @Autowired
    private TransactionService transactionService;
    @Autowired
    private UserService userService;
    @PostMapping("/transactions")
    public ResponseEntity<TransactionResponseDTo> createTransaction(@RequestBody TransactionRequestDTO transactionRequestDTO) {
        // Create a Transaction entity from the DTO
        Transaction transaction = new Transaction();
        transaction.setPrice(transactionRequestDTO.getPrice());
        transaction.setDescription(transactionRequestDTO.getDescription());
    
        // Retrieve the customer/user by ID and set it in the transaction entity
        User customer = userService.getUserById(transactionRequestDTO.getCustomer().getUserID());
        transaction.setCustomer(customer);
    
        // Call your service to save the transaction
        Transaction createdTransaction = transactionService.createTransaction(transaction);
    
        // Create a response DTO and return it
        TransactionResponseDTo responseDTO = new TransactionResponseDTo();
        responseDTO.setTransactionId(createdTransaction.getTransactionID());
        responseDTO.setPrice(createdTransaction.getPrice());
        responseDTO.setDescription(createdTransaction.getDescription());
    
        return ResponseEntity.ok(responseDTO);
    }
    
    @GetMapping("/get/{transactionID}")
    public ResponseEntity<TransactionResponseDTo> getTransaction(@PathVariable Integer transactionID) {
        // Call the service layer to retrieve the event by ID
        Transaction transaction = transactionService.getTransactionById(transactionID);
        // Map the event entity to the response DTO within the controller method
        TransactionResponseDTo responseDTO = new TransactionResponseDTo();
        responseDTO.setTransactionId(transaction.getTransactionID());
        responseDTO.setDescription(transaction.getDescription());
        responseDTO.setPrice(transaction.getPrice());
        // Set other relevant fields
        return ResponseEntity.ok(responseDTO);
    }
    @GetMapping("/get")
    public ResponseEntity<List<TransactionResponseDTo>> getAllTransaction() {
        // Call the service layer to retrieve all events
        List<Transaction> transactions = transactionService.getAllTransaction();

        // Map the list of event entities to a list of response DTOs within the controller method
        List<TransactionResponseDTo> responseDTOs = transactions.stream()
                .map(transaction -> {
                    TransactionResponseDTo responseDTO = new TransactionResponseDTo();
                    responseDTO.setTransactionId(transaction.getTransactionID());
                    responseDTO.setDescription(transaction.getDescription());
                    responseDTO.setPrice(transaction.getPrice());
                    // Set other relevant fields
                    return responseDTO;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(responseDTOs);
    }
    @PutMapping("/put/{transactionID}")
    public ResponseEntity<TransactionResponseDTo> updateEvent(@PathVariable Integer transactionID, @RequestBody FlavourRequestDTO transactionRequestDTO) {
        // Call the service layer to update the event by ID
        Transaction existingTransaction = transactionService.getTransactionById(transactionID);

        // Update the existing event entity with the data from the DTO
        existingTransaction.setDescription(transactionRequestDTO.getDescription());
        existingTransaction.setPrice(transactionRequestDTO.getPrice());
        // Update other relevant fields
        // Call the service layer to save the updated event
        Transaction updatedTransaction = transactionService.updateTransaction(existingTransaction);
        // Map the updated event entity to the response DTO within the controller method
        TransactionResponseDTo responseDTO = new TransactionResponseDTo();
        responseDTO.setTransactionId(updatedTransaction.getTransactionID());
        responseDTO.setDescription(updatedTransaction.getDescription());
        responseDTO.setPrice(updatedTransaction.getPrice());
        // Set other relevant fields
        return ResponseEntity.ok(responseDTO);
    }
    @DeleteMapping("/del/{transactionID}")
    public ResponseEntity<Void> deleteEvent(@PathVariable Integer transactionID) {
        // Call the service layer to delete the event by ID
        transactionService.deleteTransaction(transactionID);
        return ResponseEntity.noContent().build();
    }
}
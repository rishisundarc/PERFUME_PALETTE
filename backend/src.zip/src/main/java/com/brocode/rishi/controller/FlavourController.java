package com.brocode.rishi.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.brocode.rishi.dto.FlavourResponseDTO;
import com.brocode.rishi.model.Flavour;
import com.brocode.rishi.dto.FlavourRequestDTO;
import com.brocode.rishi.service.FlavourService;
import java.util.List;
import java.util.stream.Collectors;
@RestController
@RequestMapping("/api/flavour")
public class FlavourController {
    @Autowired
    private FlavourService eventService;
    @PostMapping("/post")
    public ResponseEntity<FlavourResponseDTO> createEvent(@RequestBody FlavourRequestDTO eventRequestDTO) {
        Flavour event = new Flavour();
        event.setName(eventRequestDTO.getName());
        event.setDescription(eventRequestDTO.getDescription());
        event.setStock(eventRequestDTO.getStock());
        event.setPrice(eventRequestDTO.getPrice());
        // Set other relevant fields
        // Call the service layer to create the event
        Flavour createdEvent = eventService.createEvent(event);
        // Map the created event entity to the response DTO within the controller method
        FlavourResponseDTO responseDTO = new FlavourResponseDTO();
        responseDTO.setFlavourID(createdEvent.getFlavourID());
        responseDTO.setName(createdEvent.getName());
        responseDTO.setDescription(createdEvent.getDescription());
        responseDTO.setStock(createdEvent.getStock());
        responseDTO.setPrice(createdEvent.getPrice());
        // Set other relevant fields
        return ResponseEntity.ok(responseDTO);
    }
    @GetMapping("/get/{eventID}")
    public ResponseEntity<FlavourResponseDTO> getEvent(@PathVariable Integer eventID) {
        // Call the service layer to retrieve the event by ID
        Flavour event = eventService.getFlavourById(eventID);
        // Map the event entity to the response DTO within the controller method
        FlavourResponseDTO responseDTO = new FlavourResponseDTO();
        responseDTO.setFlavourID(event.getFlavourID());
        responseDTO.setName(event.getName());
        responseDTO.setDescription(event.getDescription());
        responseDTO.setStock(event.getStock());
        responseDTO.setPrice(event.getPrice());
        // Set other relevant fields
        return ResponseEntity.ok(responseDTO);
    }
    @GetMapping("/get")
    public ResponseEntity<List<FlavourResponseDTO>> getAllEvents() {
        // Call the service layer to retrieve all events
        List<Flavour> events = eventService.getAllEvents();

        // Map the list of event entities to a list of response DTOs within the controller method
        List<FlavourResponseDTO> responseDTOs = events.stream()
                .map(event -> {
                    FlavourResponseDTO responseDTO = new FlavourResponseDTO();
                    responseDTO.setFlavourID(event.getFlavourID());
                    responseDTO.setName(event.getName());
                    responseDTO.setDescription(event.getDescription());
                    responseDTO.setStock(event.getStock());
                    responseDTO.setPrice(event.getPrice());
                    // Set other relevant fields
                    return responseDTO;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(responseDTOs);
    }
    @PutMapping("/put/{flavourID}")
    public ResponseEntity<FlavourResponseDTO> updateEvent(@PathVariable Integer flavourID, @RequestBody FlavourRequestDTO eventRequestDTO) {
        // Call the service layer to update the event by ID
        Flavour existingEvent = eventService.getFlavourById(flavourID);

        // Update the existing event entity with the data from the DTO
        existingEvent.setName(eventRequestDTO.getName());
        existingEvent.setDescription(eventRequestDTO.getDescription());
        existingEvent.setStock(eventRequestDTO.getStock());
        existingEvent.setPrice(eventRequestDTO.getPrice());
        // Update other relevant fields
        // Call the service layer to save the updated event
        Flavour updatedEvent = eventService.updateEvent(existingEvent);
        // Map the updated event entity to the response DTO within the controller method
        FlavourResponseDTO responseDTO = new FlavourResponseDTO();
        responseDTO.setFlavourID(updatedEvent.getFlavourID());
        responseDTO.setName(updatedEvent.getName());
        responseDTO.setDescription(updatedEvent.getDescription());
        responseDTO.setStock(updatedEvent.getStock());
        responseDTO.setPrice(updatedEvent.getPrice());
        // Set other relevant fields
        return ResponseEntity.ok(responseDTO);
    }
    @DeleteMapping("/del/{flavourID}")
    public ResponseEntity<Void> deleteEvent(@PathVariable Integer flavourID) {
        // Call the service layer to delete the event by ID
        eventService.deleteEvent(flavourID);
        return ResponseEntity.noContent().build();
    }
}
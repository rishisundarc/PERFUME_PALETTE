package com.brocode.rishi.dto;

import com.brocode.rishi.model.User;

import jakarta.persistence.Lob;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TransactionRequestDTO{
    @Lob
    private String description;
    private double price;
    private User customer;
}
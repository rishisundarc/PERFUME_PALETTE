package com.brocode.rishi.dto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FlavourRequestDTO {
    private Integer flavourId;
    private String name;
    private String description;
    private Integer stock;
    private double price;
}
package com.brocode.rishi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.brocode.rishi.model.Flavour;

public interface FlavourRepository  extends JpaRepository<Flavour, Integer>  {

}

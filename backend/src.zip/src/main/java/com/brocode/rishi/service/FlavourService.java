package com.brocode.rishi.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.brocode.rishi.model.Flavour;
import com.brocode.rishi.repository.FlavourRepository;
import java.util.List;
import java.util.Optional;
@Service
public class FlavourService {

    @Autowired
    private FlavourRepository eventRepository;

    public Flavour createEvent(Flavour event) {
        // Implement logic to create and save an event
        return eventRepository.save(event);
    }

    public Flavour getFlavourById(Integer flavourId) {
        // Implement logic to retrieve an event by ID
        Optional<Flavour> eventOptional = eventRepository.findById(flavourId);
        return eventOptional.orElse(null);
    }

    public List<Flavour> getAllEvents() {
        // Implement logic to retrieve all events
        return eventRepository.findAll();
    }

    public Flavour updateEvent(Flavour event) {
        // Implement logic to update and save an event
        return eventRepository.save(event);
    }

    public void deleteEvent(Integer eventId) {
        // Implement logic to delete an event by ID
        eventRepository.deleteById(eventId);
    }
}

package com.brocode.rishi.dto;

import com.brocode.rishi.model.Flavour;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrderResponse {
    private Integer orderid;
    private Integer quantity;
    private double price;
    private Flavour flavour;
    public void setFlavours(FlavourRequestDTO mapUserToUserDTO) {
    }
}
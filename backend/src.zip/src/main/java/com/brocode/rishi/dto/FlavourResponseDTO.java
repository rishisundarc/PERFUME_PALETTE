package com.brocode.rishi.dto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FlavourResponseDTO {
    private Integer flavourID;
    private String name;
    private Integer stock;
    private double price;
    private String description;
   
}
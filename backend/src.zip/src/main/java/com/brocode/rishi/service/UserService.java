package com.brocode.rishi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.brocode.rishi.model.User;
import com.brocode.rishi.repository.UserRepository;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
     public User createUser(User user) {
        // Implement logic to create and save an event
        return userRepository.save(user);
    }

    public List<User> getAllUser(){
        return userRepository.findAll();
    }
    public User getUserById(Integer userId) {
        // Use the UserRepository to find a user by their ID
        Optional<User> userOptional = userRepository.findById(userId);

        // Check if the user exists in the database
            return userOptional.get();
      
    }
    public void deleteUser(Integer userId) {
        // Implement logic to delete an event by ID
        userRepository.deleteById(userId);
    }
}

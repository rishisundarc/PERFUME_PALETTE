package com.brocode.rishi.model.enumerated;

public enum Role{
    Admin,
    USER
}